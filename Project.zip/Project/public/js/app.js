var sampleApp = angular.module('sampleApp',
 ['ngRoute',
  'appRoutes'
	]);